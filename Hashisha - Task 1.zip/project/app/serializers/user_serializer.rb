class UserSerializer < ActiveModel::Serializer
  attributes :name
end
