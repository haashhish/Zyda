class User < ApplicationRecord
    has_many :lists
end
