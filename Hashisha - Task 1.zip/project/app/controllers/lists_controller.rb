class ListsController < ApplicationController
    def index
        @list = List.all
        render json: @list
    end

    def show #used to show only second item of the list
        @currList = List.second
        render json: @currList
    end

    def create
        @newList = List.new(task:"tetsing the create function",status:"outgoing",user_id:1)
        if @newList.save
            render json:@newList
        end
    end

    def destroy
        @currList = List.last #destroys last list item
        @currList.destroy
    end

    def update
        @specificList = List.last
        @specificList.update(task:"THIS IS AN UPDATED VERSION",status:"done")
    end
end
